# AI Girlfriend Chat App

## Setup
1. Copy `.env.local.example` to `.env.local`
2. Fill in your keys
3. Run:
```bash
npm install
npm run dev
```